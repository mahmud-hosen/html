<div class="footer">
	<p class="text-center bg-dark text-light" style="margin-top:275px; padding: 20px;">All right reserved &copy; <?php echo date('Y') ?></p>
</div>

 </body>
 </html>